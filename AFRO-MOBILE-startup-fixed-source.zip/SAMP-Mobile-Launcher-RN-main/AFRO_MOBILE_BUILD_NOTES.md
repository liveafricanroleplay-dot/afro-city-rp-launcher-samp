# AFRO MOBILE build notes

## Applied in this source pass
- Renamed React Native app registration and Android launcher label to AFRO MOBILE.
- Kept Android application ID `com.touch.mobile.dark` to avoid breaking native Java/JNI and Firebase package references.
- Replaced the original developer's `.env` with a clean AFRO `.env.example`; copy it to `.env` and configure your own API/CDN endpoints.
- Translated many visible launcher labels and navigation tabs into English.
- Fixed SA-MP IPv4 query packet construction and made server monitoring use the configured `IP:PORT` instead of always querying UDP 7777.
- Added setup and verification notes.

## Still required before a working APK
1. AFRO distribution JSON endpoint and CDN/cache hosting URL.
2. AFRO news and donation API endpoints (or remove/disable those modules).
3. Confirm UDP query is enabled on `142.132.203.47:14585`.
4. Build with Android SDK/NDK and verify on a real Android phone.
5. Supply a legally usable AFRO logo, splash artwork and launcher icon.
6. Confirm rights/permission for the inherited launcher source and native game/client binaries before public distribution.

## Not yet verified
No APK has been built in this environment. Dependency installation, Gradle compilation, APK signing, live server query and full game launch remain unverified.


## APK build through GitHub Actions

A GitHub Actions workflow is included at `.github/workflows/android-debug-apk.yml`. Push this project to the `main` or `master` branch, or open the repository's Actions tab and run **Build AFRO MOBILE APK** manually. When the workflow succeeds, open its run and download the `AFRO-MOBILE-debug-APK` artifact. Extract it on your phone and install `app-debug.apk`.

The included distribution file lists the AFRO CITY RP server at `142.132.203.47:14585`. The news and donation API endpoints are intentionally placeholders because no AFRO website/API was supplied. Game cache downloads, launcher self-updates, push notifications, and real server/device testing are not verified yet. The supplied native game libraries are only for `armeabi-v7a`; do not assume 64-bit native support.
