# AFRO MOBILE — SA-MP Android Launcher

This repository contains the React Native Android launcher source adapted for the AFRO CITY RP project.

## Important compatibility notes

- The native Android application ID remains `com.touch.mobile.dark` in this first safe adaptation. Native Java packages, JNI/native libraries, manifest references and the included Firebase configuration all depend on it. Changing it requires a coordinated native migration and a new Firebase Android app configuration.
- The supplied native game libraries currently include `armeabi-v7a` only. This package must not be advertised as ARM64-ready until compatible 64-bit SA-MP/GTA libraries are supplied and tested.
- The launcher distribution API is required for game cache metadata, CDN paths, news, donations and server entries. Configure the AFRO endpoints in `.env`; do not point this build at the original Touch RP service.
- The SA-MP UDP server monitor now reads the IPv4 address as numeric bytes and queries the port included in each server address.

## Setup

1. Install Node.js compatible with React Native 0.70, Yarn 1.x, JDK 11/17, Android SDK and the Android NDK version specified in `android/build.gradle`.
2. Copy `.env.example` to `.env` and replace every `YOUR-...` value with AFRO CITY RP endpoints. The distribution endpoint must return the JSON structure documented by `src/services/distribution.service.ts`.
3. Install dependencies with `yarn install`.
4. Start Metro with `yarn start`.
5. Build a debug app on an Android development machine with `yarn android`.
6. Build a release APK with `cd android && ./gradlew assembleRelease`. A production release also needs a private signing key; never commit that key.

## AFRO CITY RP server

The hosting details previously supplied for the game server were `142.132.203.47:14585`. Confirm that the server's SA-MP query protocol is enabled and reachable over UDP before publishing this address in the distribution JSON. The launcher does not invent online player counts when a query fails.

## Current verification status

Source-level changes have been made to the launcher name, visible English UI labels and SA-MP server query handling. A complete Android build and on-device connection test have **not** yet been completed. The project requires its AFRO distribution/news/donation backend configuration and a machine with the Android build toolchain.


## Build an APK using GitHub Actions

1. Upload/push this source project to your GitHub repository on `main` or `master`.
2. Open the repository on GitHub and choose **Actions**.
3. Select **Build AFRO MOBILE APK**, then choose **Run workflow** (or wait for the push build).
4. When the run is green, open it and download the `AFRO-MOBILE-debug-APK` artifact.
5. Extract the artifact and install `app-debug.apk` on your Android phone.

This repository includes a starter distribution JSON for the AFRO CITY RP server. News and donation APIs are not configured, and the game cache/download CDN has not been supplied, so those features are not ready. This is a debug/test APK workflow, not a signed Play Store release.
